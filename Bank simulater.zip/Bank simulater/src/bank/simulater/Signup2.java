
package bank.simulater;
import java.awt.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.*;

public class Signup2 extends JFrame implements ActionListener{
   
    JLabel additional,religionL,categoryL,incomeL,educationL,educationL1,occupationL,panL,aadharL,seniorCitizenL, existingAccountL;
    JComboBox religionCB,categoryCB,incomeCB,educationCB,occupationCB ;
   JTextField panT,aadharT;
   JRadioButton sCitizenYes,sCitizenNo,existingAcYes,existingAcNo;
    JButton next;
    
    String formnum;
    long formn;
    
    Signup2(String formno)
     {         
   setLayout(null);
   formnum = formno;
   formn =Long.parseLong(formnum);
    
    
             ImageIcon backg=new ImageIcon(ClassLoader.getSystemResource("icons/Signup.jpg"));
    JLabel bg=new JLabel("",backg,JLabel.CENTER);
    bg.setBounds(0,0,900,1000);
    add(bg);
    
    ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/logobnk.png"));
        Image i2 = i1.getImage().getScaledInstance(60, 75, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l14 = new JLabel(i3);
        l14.setBounds(160, 10, 70, 70);
        bg.add(l14);
    
       setTitle("NEW ACCOUNT APPLICATION FORM- PAGE-2  "+formn);
       
        //labels
        additional=new JLabel("Page 2: Additional Details  "+formno);
        additional.setBounds(250,40,400,30); 
        additional.setFont(new Font("Relway",Font.BOLD,22));
        bg.add(additional);
        additional.setForeground(Color.WHITE);
        
       
        
        
      religionL =new JLabel("Religion:");
        religionL.setBounds(150,120,150,20);
        religionL.setFont(new Font("Relway",Font.BOLD,18));
        bg.add(religionL);
        religionL.setForeground(Color.WHITE);
        
        categoryL=new JLabel("Category:");
        categoryL.setBounds(150,160,150,20);
        categoryL.setFont(new Font("Relway",Font.BOLD,18));
        bg.add(categoryL);
        categoryL.setForeground(Color.WHITE);
        
        incomeL=new JLabel("Income:");
        incomeL.setBounds(150,200,150,20);
        incomeL.setFont(new Font("Relway",Font.BOLD,18));
        bg.add(incomeL);
        incomeL.setForeground(Color.WHITE);
        
        educationL=new JLabel("Educational:");
        educationL.setBounds(150,240,150,20);
        educationL.setFont(new Font("Relway",Font.BOLD,18));
        bg.add(educationL);
        educationL.setForeground(Color.WHITE);
          educationL1=new JLabel("Qualification");
        educationL1.setBounds(150,265,150,20);
        educationL1.setFont(new Font("Relway",Font.BOLD,18));
        bg.add(educationL1);
        educationL1.setForeground(Color.WHITE);
       
        occupationL=new JLabel("Occupation:");
        occupationL.setBounds(150,305,150,20);
        occupationL.setFont(new Font("Relway",Font.BOLD,18));
        bg.add(occupationL);
        occupationL.setForeground(Color.WHITE);
        
         panL=new JLabel("Pan Number:");
        panL.setBounds(150,345,150,20);
        panL.setFont(new Font("Relway",Font.BOLD,18));
        bg.add(panL);
        panL.setForeground(Color.WHITE);
        
         
         aadharL=new JLabel("Aadhar Number:");
        aadharL.setBounds(150,385,150,20);
        aadharL.setFont(new Font("Relway",Font.BOLD,18));
        bg.add(aadharL);
        aadharL.setForeground(Color.WHITE);
        
         seniorCitizenL =new JLabel("Senior Citizen:");
         seniorCitizenL.setBounds(150,425,150,20);
        seniorCitizenL.setFont(new Font("Relway",Font.BOLD,18));
        bg. add(seniorCitizenL) ;
        seniorCitizenL.setForeground(Color.WHITE);
         
          
         existingAccountL=new JLabel("Existing Account:");
         existingAccountL.setBounds(150,465,180,20);
         existingAccountL.setFont(new Font("Relway",Font.BOLD,18));
       bg. add( existingAccountL);
       existingAccountL.setForeground(Color.WHITE);
        
        
        
        //comboBox
        
        String r[]={"Hindu","Islam","Sikh","Christian","Others"};
       religionCB=new JComboBox(r);
       religionCB.setBounds(320,120,280,20);
      bg. add(religionCB);
      
       String  c[]={"General","OBC","SC","ST","Others"};
     categoryCB=new JComboBox(c);
       categoryCB.setBounds(320,160,280,20);
       bg.add(categoryCB);
       
       String inc[]={"NULL","More than 2 Lakh","More than 5 Lakh","More than 10 Lakh"};
        incomeCB=new JComboBox(inc);
      incomeCB.setBounds(320,200,280,20);
      bg.add(incomeCB);
      
       String edu[]={"Non-Graduate","Graduate","Post-Graduate","Others"};
        educationCB=new JComboBox(edu);
       educationCB.setBounds(320,250,280,20);
      bg. add(educationCB);
       
        String oc[]={"Student","Salaried","Business","Self Employed","Others"};
         occupationCB=new JComboBox(oc);
     occupationCB.setBounds(320,305,280,20);
      bg. add(occupationCB);
       
         panT=new JTextField();
       panT.setBounds(320,345,280,20);
       bg.add(panT);
     
        aadharT=new JTextField();
       aadharT.setBounds(320,385,280,20);
       bg.add(aadharT);
       
       sCitizenYes =new JRadioButton("Yes");
       sCitizenYes.setBounds(320,425,50,20);
      bg. add(sCitizenYes);
       sCitizenYes.setBackground(Color.WHITE);
       
        sCitizenNo =new JRadioButton("NO");
       sCitizenNo.setBounds(400,425,50,20);
      bg. add(sCitizenNo);
       sCitizenNo.setBackground(Color.WHITE);
       
       ButtonGroup btg=new ButtonGroup();
       btg.add(sCitizenYes);
       btg.add(sCitizenNo);
       
       
       existingAcYes =new JRadioButton("Yes");
      existingAcYes.setBounds(320,465,50,20);
       bg.add(existingAcYes);
       existingAcYes.setBackground(Color.WHITE);
       
        existingAcNo =new JRadioButton("No");
        existingAcNo.setBounds(400,465,50,20);
       bg.add( existingAcNo);
       existingAcNo.setBackground(Color.WHITE);
       
       ButtonGroup btg1=new ButtonGroup();
       btg1.add( existingAcYes);
       btg1.add( existingAcNo);
       
       
       
       //button
       
       next=new JButton("NEXT");
       next.setBounds(520,530,80,30);
         next.addActionListener(this);
         next.setBackground(Color.BLACK);
         next.setForeground(Color.WHITE);
       bg.add(next);
     
//frame property   
    setSize(800,840);
    setVisible(true);
    setLocation(250,5);
    getContentPane().setBackground(Color.WHITE);
        
    
    }
    
    public void actionPerformed(ActionEvent e)
    {
        String formno=""+formn;
        String religion=(String) religionCB.getSelectedItem();
        String category=(String) categoryCB.getSelectedItem();
         String income=(String) incomeCB.getSelectedItem();
          String education=(String) educationCB.getSelectedItem();
          String occupation = (String) occupationCB.getSelectedItem();
          String pan=panT.getText();
          String aadhar=aadharT.getText();
          String seniorcitizen=null;
          if(sCitizenYes.isSelected())
          {
              seniorcitizen="yes";
          }
          else if(sCitizenNo.isSelected())
          {
              seniorcitizen="no";
          }
          
          String existingaccount=null;
          if(existingAcYes.isSelected())
          {
            existingaccount="yes";  
          }
          else if(existingAcNo.isSelected())
          {
              existingaccount="no";
          }
          
          
          //constraints
          
         if(religion.equals(""))
         {
             JOptionPane.showMessageDialog(null,"Religion Required");
             return;
         }
          else if(category.equals(""))
         {
             JOptionPane.showMessageDialog(null,"Category Required");
             return;
         }
          else if(income.equals(""))
         {
             JOptionPane.showMessageDialog(null,"Income Required");
             return;
         }
          else if(education.equals(""))
         {
             JOptionPane.showMessageDialog(null,"Education Required");
             return;
         }
          else if(occupation.equals(""))
          {
              JOptionPane.showMessageDialog(null,"Occupation Required");
              return;
          }
          else if(pan.equals(""))
          {
              JOptionPane.showMessageDialog(null,"pan Required");
              return;
          }
          else if(aadhar.equals(""))
          {
              JOptionPane.showMessageDialog(null,"aadhar Required");
              return;
          }
          
        
      //database connection    
      else
          {
            try{
              Conn c=new Conn();
            String query="insert into signup2 values('"+formno+"','"+religion+"','"+category+"','"+income+"','"+education+"','"+occupation+"','"+pan+"','"+aadhar+"','"+seniorcitizen+"','"+existingaccount+"')";
            c.s.executeUpdate(query);
          }
            catch(Exception ae)
            {
                System.out.println(ae);
            }
          }
        
     if(e.getSource()==next)
          setVisible(false);
            
          Signup3 ob=new Signup3(formno);
          ob.setVisible(true);
      }
      
      
      
    
    public static void main(String[] args)
    {
       new Signup2(""); 
    }
    
    
}
